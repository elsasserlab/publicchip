Only files that changed from the original ngsplot version.
They go where the original ones go in the main repository (bin/ and lib/)
